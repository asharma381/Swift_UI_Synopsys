//
//  View.swift
//  Hamburger_Menu
//
//  Created by Aditya Sharma on 12/26/18.
//  Copyright © 2018 Aditya Sharma. All rights reserved.
//

import Foundation

class View: UIViewController {
    
    var num: Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        //let isUserLoggedIn = UserDefaults.standard.bool(forKey: "isUserLoggedIn")
        if(num == 0){
            self.performSegue(withIdentifier: "loginView", sender: self)
            num = num.advanced(by: 1)
        }
//        }else{
//
//        }
//
        if(num == 1){
            
        }

    }
}

// FOR LOGGING OUT DO THIS ----
//      UserDefaults.standard.set(false, forKey: "isUserLoggedIn")
//      UserDefaults.standard.synchronize()
