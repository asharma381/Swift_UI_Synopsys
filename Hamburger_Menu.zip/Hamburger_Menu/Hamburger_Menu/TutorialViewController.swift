//
//  TutorialViewController.swift
//  Hamburger_Menu
//
//  Created by Aditya Sharma on 11/27/18.
//  Copyright © 2018 Aditya Sharma. All rights reserved.
//

import UIKit

class TutorialViewController: UIViewController, UIPageViewControllerDataSource {

    var pageImages:NSArray!
    var pageViewController: UIPageViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationController?.navigationItem.title = "HELLO"
       // navigationController?.navigationItem.font
        navigationController?.navigationItem.rightBarButtonItem?.setTitleTextAttributes(
            [
                NSAttributedStringKey.font : UIFont(name: "Euphemia UCAS", size: 50)!,//change to 24 later
                NSAttributedStringKey.foregroundColor : UIColor.white,
            ]
            , for: .normal)
        //Euphemia UCAS 32.0
        pageImages = ["BG", "BG", "BG"]
        
        
        self.pageViewController = self.storyboard?.instantiateViewController(withIdentifier: "page") as! UIPageViewController
        self.pageViewController.dataSource = self
        var initialViewController = self.pageTutorialAtIndex(index: 0) as TutorialPageViewController
        var viewContollers = NSArray(object: initialViewController)
        self.pageViewController.setViewControllers(viewContollers as! [UIViewController], direction: UIPageViewControllerNavigationDirection.forward, animated: true, completion: nil)
        self.pageViewController.view.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height:
            
            self.view.frame.height)
        
        //orignailly pageViewCONTROLLE.VIEW.FRAME
        //print(self.view.frame.height)
        //print(self.view.frame.size.height)
            //self.view.frame.size.height)//- 100)
        
        self.addChildViewController(self.pageViewController)
        self.view.addSubview(self.pageViewController.view)
        self.pageViewController.didMove(toParentViewController: self)
      
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    
    func pageTutorialAtIndex(index: Int) -> TutorialPageViewController{
        let pageContentViewController = self.storyboard?.instantiateViewController(withIdentifier: "TutorialPageViewController") as! TutorialPageViewController
        
        pageContentViewController.imageFileName = pageImages[index] as! String
        pageContentViewController.pageIndex = index
        
        
        return pageContentViewController
    }
    
    public func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController?
    {
        let viewController = viewController as! TutorialPageViewController
        var index = viewController.pageIndex as Int
        
        if(index == 0 || index == NSNotFound)
        {
            return nil
        }
        
        index -= 1
        
        return self.pageTutorialAtIndex(index: index)
    }
    

    public func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController?
    {
        let viewController = viewController as! TutorialPageViewController
        var index = viewController.pageIndex as Int
        
        if((index == NSNotFound))
        {
            return nil
        }
        
        index += 1
        
        if(index == pageImages.count)
        {
            return nil
        }
        
        return self.pageTutorialAtIndex(index: index)
    }
    
    

    public func presentationCount(for pageViewController: UIPageViewController) -> Int
    {
        return pageImages.count
    }
    

    public func presentationIndex(for pageViewController: UIPageViewController) -> Int
    {
        return 0
    }
    
    
    
    
    @IBAction func skipButtonTapped(_ sender: Any) {
        let defaults = UserDefaults.standard
        defaults.setValue(true, forKey: "skipTutorialPages")
        defaults.synchronize()
        
        var newView: View = self.storyboard?.instantiateViewController(withIdentifier: "View") as! View
        
        let appdelegate = UIApplication.shared.delegate as! AppDelegate
        
        appdelegate.window?.rootViewController = newView
    }
    

}
