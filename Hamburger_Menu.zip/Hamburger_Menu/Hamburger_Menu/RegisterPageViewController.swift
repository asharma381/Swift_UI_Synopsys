//
//  RegisterPageViewController.swift
//  Hamburger_Menu
//
//  Created by Aditya Sharma on 11/26/18.
//  Copyright © 2018 Aditya Sharma. All rights reserved.
//

import UIKit

class RegisterPageViewController: UIViewController {

    @IBOutlet weak var userEmailTextField: UITextField!
    
    @IBOutlet weak var userPasswordTextField: UITextField!
    
    @IBOutlet weak var repeatUserPasswordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        userEmailTextField.resignFirstResponder()
        userPasswordTextField.resignFirstResponder()
        repeatUserPasswordTextField.resignFirstResponder()
        return true
    }
    
    @IBAction func registerButtonTapped(_ sender: Any) {
        
        let userEmail = userEmailTextField.text
        let userPassword = userPasswordTextField.text
        let userRepeatPassoword = repeatUserPasswordTextField.text
        
        //Check for empty fields
        if((userEmail?.isEmpty)! || (userPassword?.isEmpty)! || (userRepeatPassoword?.isEmpty)!){
            //display alert Message
            displayMyAlertMessage(userMessage: "All fields are required.")
            return;
        }
        
        //Check if the password match
        if(userPassword != userRepeatPassoword){
            //Display an alert message
            displayMyAlertMessage(userMessage: "Passwords do not match.")
            return
        }
        
        // Store Data
        UserDefaults.standard.set(userEmail, forKey: "userEmail")
        UserDefaults.standard.set(userPassword, forKey: "userPassword")
        UserDefaults.standard.synchronize()
        
        
        // Display Alert Message with confirmation.
        let myAlert = UIAlertController(title: "Alert", message:"Registeration is successful. Thank You!", preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style: UIAlertActionStyle.default){ action in
            self.dismiss(animated: true, completion: nil)
        }
        
        myAlert.addAction(okAction)
        
        self.present(myAlert, animated: true, completion: nil)
        
    
    }
    

    func displayMyAlertMessage(userMessage:String){
        let myAlert = UIAlertController(title: "Alert", message:userMessage, preferredStyle: UIAlertControllerStyle.alert);
        
    
        let okAction = UIAlertAction(title:"Ok", style: UIAlertActionStyle.default, handler:nil)
        
        myAlert.addAction(okAction)
        
       self.present(myAlert, animated: true, completion: nil)
    }
    
    
}
