//
//  ViewController.swift
//  Hamburger_Menu
//
//  Created by Aditya Sharma on 11/22/18.
//  Copyright © 2018 Aditya Sharma. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var Open: UIBarButtonItem!
    
    var varView = Int()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        Open.target = self.revealViewController()
        Open.action = Selector("revealToggle:")
        
        self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        
        if(varView == 0){
            label.text = "Strings"
        }else{
            label.text = "Others"
        }
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // if the logout button is clicked
        //Do this...
    
    //  UserDefaults.standard.set(false, forKey: "isUserLoggedIn")
    //  UserDefaults.standard.synchronize()

}

