//
//  Second.swift
//  Hamburger_Menu
//
//  Created by Aditya Sharma on 12/22/18.
//  Copyright © 2018 Aditya Sharma. All rights reserved.
//

import Foundation
import UIKit

class Second: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate{
    @IBOutlet weak var myImageView: UIImageView!
    
    override func viewDidLoad() {
        self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
    }
    
    @IBAction func chooseImage(_ sender: Any) {
        let image = UIImagePickerController()
       
        //image.delgate = self
        image.sourceType = UIImagePickerControllerSourceType.photoLibrary
        image.allowsEditing = false
        image.view.tag = myImageView.tag
        self.present(image, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage
        {
            myImageView.image = image
            print("we got the image but something else happened")
        }else{
            //Error Message
            print("Error!")
        }
        self.dismiss(animated: true, completion: nil)
    }
}
