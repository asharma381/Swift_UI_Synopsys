//
//  Hello.swift
//  Hamburger_Menu
//
//  Created by Aditya Sharma on 1/22/19.
//  Copyright © 2018 Aditya Sharma. All rights reserved.
//

import Foundation

class Hello: UIViewController {
    override func viewDidLoad() {
        self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
    }
}
